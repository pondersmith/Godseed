﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI; 

public class GameManager : MonoBehaviour
{
		// static reference to game manager so can be called from other scripts directly (not just through gameobject component)
	public static GameManager gm;
	int lastPanel=0;
	[SerializeField]
	GameObject[] UIpanels=new GameObject[12];

	[SerializeField]
	GameObject UImenu=null;

	[SerializeField]
	GameObject UImenuIcon=null;

	void Awake()
	{
		// setup reference to game manager
		if (gm == null)
			gm = this.GetComponent<GameManager>();

		// setup all the variables, the UI, and provide errors if things not setup properly.
		//setupDefaults();
	}


	public void GoUI(int panelID){
		MenuClose();
		UIpanels[panelID].SetActive(true);
		lastPanel=panelID;
	}
	public void MenuClose(){
		UImenu.SetActive(false);
		UImenuIcon.SetActive(true);
	}
	public void MenuOpen(){
		UIpanels[lastPanel].SetActive(false);
		UImenu.SetActive(true);
		UImenuIcon.SetActive(false);
		//pause current environment?
	}
}
